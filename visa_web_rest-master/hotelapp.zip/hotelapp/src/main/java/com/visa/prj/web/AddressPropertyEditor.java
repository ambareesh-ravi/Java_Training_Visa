package com.visa.prj.web;

import java.beans.PropertyEditorSupport;

public class AddressPropertyEditor extends PropertyEditorSupport {
	@Override
	public String getAsText() {
		// TODO Auto-generated method stub
		return super.getAsText();
	}
	
	@Override
	public void setAsText(String text) throws IllegalArgumentException {
		String[] arr = text.split(",");
		super.setAsText(text);
	}
}
